package org.cap.view;

import java.util.Scanner;

import org.cap.model.Registration;
import org.cap.util.Utility;

public class UserInteraction {
	Scanner sc=new Scanner(System.in);
	public Registration PromptRegDeatils()
	{
		Utility u=new Utility();
		Registration reg=new Registration();
		System.out.println("Enter the Customer Details");
		boolean flag=false;
		String s;
		do
		{
			
			System.out.println("Enter the Customer name");
		 s=sc.next();
		flag=u.isValidName(s);
		if(!flag)
		
			System.out.println("Enter Valid name.Name should contain only alphabets");
		}while(!flag);
		reg.setCustName(s);
		boolean flag1=false;
		String s1;
		do
		{
			
			System.out.println("Enter the mobile no");
		 s1=sc.next();
		flag1=u.isValidMobNo(s1);
		if(!flag1)
		
			System.out.println("Enter Valid number.Number should contain 10 digits");
		}while(!flag1);
		System.out.println("Enter the age");
		int s3=sc.nextInt();
		reg.setAge(s3);
		return reg;
		
	}
	

}
