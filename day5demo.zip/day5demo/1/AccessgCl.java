package org.cap.demo;
import Balance.Account;
public class AccessgCl {

	
	
	public static void main(String[] args) {
	Account ag=new Account();
	ag.DisplayBal();

	}

}
