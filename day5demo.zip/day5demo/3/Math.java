package org.cap.demo;

public interface Math {
public void division(int a,int b);
public void modulus(int a,int b);
}
