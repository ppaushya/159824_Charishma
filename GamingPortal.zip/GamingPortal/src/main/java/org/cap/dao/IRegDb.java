package org.cap.dao;

import org.cap.model.Registration;

public interface IRegDb {
	public void createRegistration(Registration reg);
}
