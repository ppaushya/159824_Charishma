package org.cap.demo;


public class Factorial
{
    public  void fact(int num)
    {
        int fac,prod=1;
        for(int i=1;i<=num;i++)
    {
       prod=prod*i ;
    }
    System.out.print(prod);
    }
    public static void main(String[] args)
    {
        Factorial fl=new Factorial();
        fl.fact(7);
    }
}
