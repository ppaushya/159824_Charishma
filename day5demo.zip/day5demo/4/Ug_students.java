package org.cap.demo;

public class  Ug_students implements Students{
public void Display_grade()
{
	System.out.println("Grade ug");
}
public void Attendance()
{
	System.out.println("Attendance ug");
}
}
