package org.cap.util;

public class Utility {
public boolean isValidName(String s)
{
	return (s.matches("^([a-zA-Z]+)$"));
}
public boolean isValidMobNo(String s)
{
	return (s.matches("^([1-9][0-9]{9})$"));
}
}
