package org.cap.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.cap.model.Registration;

public class RegDbImpl implements IRegDb {
public void createRegistration(Registration reg)

{

	String sql="insert into Registration values(?,?,?,?,?,?)";
	try(Connection conn=getDbConnection()) {
	
			
			PreparedStatement statement=conn.prepareStatement(sql);
			statement.setInt(1,reg.getRegistrationId());
			statement.setString(2, reg.getCustName());
			statement.setString(3, reg.getMobileNo());
			statement.setInt(4, reg.getAge());
		
			
			

			int count=statement.executeUpdate();
			
			if(count>0)
				System.out.println("Insertion done!");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}
private Connection getDbConnection() {
	Connection connection=null;
	try{	
		Class.forName("com.mysql.jdbc.Driver");
		connection=DriverManager.getConnection
				("jdbc:mysql://localhost:3306/mydb", "root", "India123");
		return connection;
	}catch (ClassNotFoundException|SQLException e) {
		e.printStackTrace();
	}
	
	return null;
	
}

	
}

