package org.capg.view;
import java.time.LocalDate;
import java.util.Scanner;

import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.util.Utility;
public class UserInteraction {
	Scanner scan=new Scanner(System.in);
  public Customer getCustomerDetails() {
	  Customer customer=new Customer();
	  customer.setCustomerId(Utility.generateNumber());
	  customer.setFirstName(promptFirstName());
	  customer.setLastName(promptLastName());
	  customer.setMobileNo(promptMobileNo());
	  customer.setEmailId(promptEmailId());
	  customer.setDateOfBirth(promptDob());
	  customer.setAddress(promptAddress());
	return customer;
	  
  }


private Address promptAddress() {

	Address address=new Address();
	String address1,address2,city,state;
	String pin;
	System.out.println("Enter first address line:");
	address1=scan.nextLine();
	System.out.println("Enter second address line:");
	address2=scan.nextLine();
	System.out.println("Enter city:");
	city=scan.nextLine();
	System.out.println("Enter state:");
	state=scan.nextLine();
	boolean flag=false;
	
	do{
		System.out.println("Enter PINCODE:");
		pin=scan.next();
		flag=Utility.isValidationPin(pin);
		if(!flag)
		{
			System.out.println("Please Enter valid Pincode");
		}
	}while(!flag);
	
	address.setAddressLine1(address1);
	address.setAddressLine2(address2);
	address.setCity(city);
	address.setState(state);
	address.setPinCode(pin);
		return address;

	
	
}


private LocalDate promptDob() {
	
	int year,month,dayOfMonth;
	System.out.println("Enter  your date of birth YYYY/MM/DD ");
	LocalDate dob;
	boolean flag=false;
	do{
		year=scan.nextInt();
	
	month=scan.nextInt();
	dayOfMonth=scan.nextInt();
	 dob=LocalDate.of(year, month, dayOfMonth);
	if(dob.compareTo(LocalDate.now())>0)
	{
		System.out.println("Date of birth is not valid");
	}
	else flag=true;
	}while(!flag);
	return dob;
}






private String promptFirstName() {
String fname;
boolean flag=false;
do{
	System.out.println("Enter Firstname: ");
	fname=scan.next();
	flag=Utility.isValidation(fname);
	if(!flag)
	{
		System.out.println("Please Enter valid FirstName");
	}
}while(!flag);
	return fname;
}

private String promptLastName() {
String lname;
boolean flag=false;
do{
	System.out.println("Enter Lastname: ");
	lname=scan.next();
	flag=Utility.isValidation(lname);
	if(!flag)
	{
		System.out.println("Please Enter valid LastName");
	}
}while(!flag);
	return lname;
}
private String promptMobileNo() {

	String  mno;
	boolean flag=false;
	do{
		System.out.println("Enter Mobile Number: ");
		mno=scan.next();
		flag=Utility.isValidationphno(mno);
		if(!flag)
		{
			System.out.println("Please Enter valid Mobile Number");
		}
	}while(!flag);
		return mno;
	
}
private String promptEmailId() {
	// TODO Auto-generated method stub
	String email;
	boolean flag=false;
	do{
		System.out.println("Enter EmailId: ");
		email=scan.next();
		flag=Utility.isValidationemail(email);
		if(!flag)
		{
			System.out.println("Please Enter valid EmailId");
		}
	}while(!flag);
	
	return email;
}

	
}
