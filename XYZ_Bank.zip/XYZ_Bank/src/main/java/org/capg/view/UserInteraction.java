package org.capg.view;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

import org.capg.model.Account;
import org.capg.model.AccountType;
import org.capg.model.Address;
import org.capg.model.Customer;
import org.capg.util.Utility;



public class UserInteraction {

	Scanner scanner=new Scanner(System.in);
	
	
	
	
	public void printCustomers(List<Customer> customers) {
		System.out.println("CustomerId\tCustomerName\tEmailId\tMobile");
		System.out.println("-----------------------------------------------------------------------------");
		
		for(Customer customer:customers) {
			System.out.println(customer.getCustomerId()
					+"\t\t"+customer.getFirstName()+" " + customer.getLastName()
					+"\t"+ customer.getEmailId() + "\t" + customer.getMobileNo() );
		}
	}

	public Customer getCustomerDetails() {
		
		Customer customer=new Customer();
		
		customer.setCustomerId(Utility.generateNumber());
		customer.setFirstName(promptFirstName());
		customer.setLastName(promptLastName());
		customer.setEmailId(promptEmailId());
		customer.setMobileNo(promptMobile());
		customer.setDateOfBirth(promptDateOfBirth());
		
		customer.setAddress(getAddressDetails());
		
		return customer;
	}
	
	
	
	
	public Address getAddressDetails() {
		Address address=new Address();
		System.out.println("Enter AddressLine1:");
		address.setAddressLine1(scanner.next());
		System.out.println("Enter AddressLine2:");
		address.setAddressLine2(scanner.next());
		System.out.println("Enter City:");
		address.setCity(scanner.next());
		System.out.println("Enter State:");
		address.setState(scanner.next());
		address.setPinCode(promptPincode());
		return address;
	}
	
	
	public String promptPincode() {
		boolean flag=false;
		String pincode;
		do {
			System.out.println("Enter pincode:");
			pincode=scanner.next();
			flag=Utility.isValidPincode(pincode);
			if(!flag)
				System.out.println("Please enter Valid pincode!");
		}while(!flag);
		
		return pincode;
	}

	public LocalDate promptDateOfBirth() {
		boolean flag=false;
		String dob;
		do {
			System.out.println("Enter DateOfBirth[dd-mm-yyyy]:");
			dob=scanner.next();
			flag=Utility.isValidDob(dob);
			if(!flag)
				System.out.println("Please enter Valid Date!");
		}while(!flag);
		String[] dates=dob.split("-");
		LocalDate date=LocalDate.of(Integer.parseInt(dates[2]), 
				Integer.parseInt(dates[1]), Integer.parseInt(dates[0]));
		return date;
	}
	
	public String promptMobile() {
		boolean flag=false;
		String mobile;
		do {
			System.out.println("Enter mobile Number:");
			mobile=scanner.next();
			flag=Utility.isValidMobile(mobile);
			if(!flag)
				System.out.println("Please enter Valid 10 digit Mobile!");
		}while(!flag);
		
		return mobile;
	}
	
	public String promptFirstName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter FirstName:");
			fname=scanner.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid FirstName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptLastName() {
		boolean flag=false;
		String fname;
		do {
			System.out.println("Enter LastName:");
			fname=scanner.next();
			flag=Utility.isValidName(fname);
			if(!flag)
				System.out.println("Please enter Valid LastName!");
		}while(!flag);
		
		return fname;
	}
	
	public String promptEmailId() {
		boolean flag=false;
		String email;
		do {
			System.out.println("Enter EmailId:");
			email=scanner.next();
			flag=Utility.isValidEmail(email);
			if(!flag)
				System.out.println("Please enter Valid EmailId!");
		}while(!flag);
		
		return email;
	}
public Account promptAccountDetails() {
	AccountType actype=AccountType.SAVINGS;
	Account acc=new Account();
	int accountNo=Utility.generateNumber();
	System.out.println("Choose account type u want to create 1.Savings 2.FD 3.RD 4.Current");
	int choice =scanner.nextInt();
	switch(choice)
	{
	case 1:
		actype=AccountType.SAVINGS;
		break;
	case 2:
		actype=AccountType.FD;
	break;
	case 3:
		actype=AccountType.RD;
		break;
	case 4:
		actype=AccountType.CURRENT;
		break;
		default:
			System.out.println("Account type doesn't exist");
		break;
		
	}
	LocalDate openingdate=LocalDate.now();
	System.out.println("Enter Opening Balance");
	
	
	Double openingBalance=scanner.nextDouble();
	System.out.println("Enter Description:");
	String desc=scanner.next();
	acc.setAccountNumber(accountNo);
	acc.setAccountType(actype);
	acc.setIopeningdate(openingdate);
	acc.setOpeningBalance(openingBalance);
	acc.setDescription(desc);
	return acc;
}
public Customer findCustomer(List<Customer> customers)
{
	System.out.println("Enter customer id for whom u want to create account");
	int cstid=scanner.nextInt();
	Customer c1 = null;
	for(Customer cs:customers)
	{
		if(cstid==cs.getCustomerId())
		{
			 c1=cs;
		}
		
	}
	return c1;
}
public void printAccounts(Set<Account> account)
{
	 
	for(Account ac:account)
	{
		System.out.println(ac);
	}

	
}
public void customerAccounts(Customer cus)
{
	
Set<Account> acc1=cus.getAccount();
for(Account ac:acc1)
{
	System.out.println(ac);
}
		
	
}

	public void printError(String message) {
		System.out.println(message);
		
	}
	
	
}
