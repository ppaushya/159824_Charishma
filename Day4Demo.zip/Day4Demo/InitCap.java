package org.cap.demo;
import java.util.*;
public class InitCap
{
	char Arr[];
	public void LetterCapitilize(String str)
	{
		Arr=new char[str.length()];
for(int i=0;i<str.length();i++)
{
	Arr[i]=str.charAt(i);
}
		for(int i=0;i<str.length();i++)
		{
			if(Arr[i]==' ')
			{
				Arr[i+1] = (char) (Arr[i+1] - (char)(32));
		
		}
		}
		for(int j=0;j<str.length();j++)
		{
			System.out.print(Arr[j]);
		}
			

	}
	public static void main(String[] args) {
	InitCap ic=new InitCap();
	ic.LetterCapitilize(" you are so sweet");

	}

}
