package org.cap.demo;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

public class UserInteraction {
	Scanner scanner=new Scanner(System.in);
	EmployeeDao employeeDao=new EmployeeDaoImpl();
	
	
	public int promptEmployeeID() {
		System.out.println("Enter Employee Id:");
		return scanner.nextInt();
	}

	public Employee createEmployee() {
		Employee employee=new Employee();
		System.out.println("Enter Employee Id:");
		employee.setEmpId(scanner.nextInt());
		
		System.out.println("Enter Employee FirstName:");
		employee.setFirstName(scanner.next());
		
		System.out.println("Enter Employee LastName:");
		employee.setLastName(scanner.next());
		
		System.out.println("Enter Employee Salary:");
		employee.setSalary(scanner.nextDouble());
		
		System.out.println("Enter Employee DateOf Joining[yyyy-mm-dd]:");
		String[] date=scanner.next().split("-");
		employee.setEmpdoj(LocalDate.of(
				Integer.parseInt(date[0]), 
				Integer.parseInt(date[1]), 
				Integer.parseInt((date[2]))));
		
		return employee;
	}
	public void printEmployee(Employee employee) {
		System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDateOfjoining");
		
			System.out.println(employee.getEmpId() +"\t\t"
					+employee.getFirstName()+"\t" 
					+employee.getLastName()+"\t" 
					+employee.getSalary()+"\t" 
					+employee.getEmpdoj() );
		
	}
	
	public Employee UpdateEmployee(int employeeid)
	{
		System.out.println("Enter What u want to update:1.id 2.fname 3.lname 4.salary ");
		
				int s=scanner.nextInt();
				switch(s)
				{
				case 1:
					Employee emp=new Employee();
					emp=employeeDao.findEmployee(employeeid);
					System.out.println("Enter the  id u want to set");
					int n=scanner.nextInt();
					emp.setEmpId(n);
					return emp;
					break;
				case 2:
					Employee emp1=new Employee();
					emp1=employeeDao.findEmployee(employeeid);
					System.out.println("Enter the first name u want to set");
					String n1=scanner.next();
					emp1.setFirstName(n1);
					return emp1;
					break;
				case 3:
					Employee emp2=new Employee();
					emp2=employeeDao.findEmployee(employeeid);
					System.out.println("Enter the last name u want to set");
					String n2=scanner.next();
					emp2.setFirstName(n2);
					return emp2;
					break;
				case 4:
					Employee emp3=new Employee();
					emp3=employeeDao.findEmployee(employeeid);
					System.out.println("Enter the salary u want to set");
					Double n3=scanner.nextDouble();
					emp3.setSalary(n3);
					return emp3;
					break;
					default:
						System.out.println("Invalid Option");
						System.exit(0);
					
				}
	}

	public void printAllEmployees(List<Employee> employees) {
		System.out.println("EmployeeId\tFirstName\tLastName\tSalary\tDateOfjoining");
		for(Employee employee:employees)
			System.out.println(employee.getEmpId() +"\t"
					+employee.getFirstName()+"\t" 
					+employee.getLastName()+"\t" 
					+employee.getSalary()+"\t" 
					+employee.getEmpdoj() );
		
	}

}
