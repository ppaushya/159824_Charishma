package org.cap.demo;

public class Pg_student implements Students {
public void Display_grade()
{
	System.out.println("Grade");
}
public void Attendance()
{
	System.out.println("Attendance");
}
}
