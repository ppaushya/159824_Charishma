package org.cap.demo;
public class StringRev{
    char Arr[];
    public void LetterChanges(String str)
    {
        Arr=new char[str.length()];
        for(int i=0;i<str.length();i++)
        {
        Arr[i]=str.charAt(i);
        }
        
        for(int k=str.length()-1;k>=0;k--)
        {
            System.out.print(Arr[k]);
        }
    }

     public static void main(String []args){
        StringRev sc=new StringRev();
        sc.LetterChanges("you are sn sweet");
     }
}
