package org.cap.demo;

public class Circ implements Area {
public float Cal(float x,float y)
{
	return (pi*x*x);
}
}
