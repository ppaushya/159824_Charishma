package org.cap.demo;

public class OddEven {
	public void assignment1(int num)

    {

           int i=0;

           int no=1;

           int no1=2;

           while(no<num)

           {

                  for(i=0;i<3;)

           {

                  if(no%2!=0)

                  {

                        System.out.print(no+" ");

                        i++;

                  }

                 

                  no++;

                  if(no>=num)

                        break;

           }

                  for(int j=0;j<3;)

                  {

                  if(no1%2==0)

                  {

                        System.out.print(no1+" ");

                        j++;

                  }

                  no1++;

                  if(no1>=num)

                        break;

                  }

                 

           }

                 

                 

           }
	public static void main(String[] args) {
	OddEven oe=new OddEven();
	oe.assignment1(20);

	}

}
