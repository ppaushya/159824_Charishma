package org.cap.demo;

public class Calc implements Math{
public void division(int a,int b)
{
	
	int r;
	r=a/b;
	System.out.println("Division is "+r);
}
public void modulus(int a,int b)
{
	int r;
	r=a%b;
	System.out.println("Modulus is "+r);
}


}
