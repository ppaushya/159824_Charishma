package org.capg.boot;

import java.util.Scanner;

import org.capg.model.Customer;
import org.capg.view.UserInteraction;

public class BootClass {
	Scanner sc=new Scanner(System.in);
public static void main(String[] args)
{
	UserInteraction user=new UserInteraction();
	Customer customer=user.getCustomerDetails();
	/*ICustomerService customerservice=new CustomerServiceImpl();
	List<Customer> customers=customerService.getAllCutsomers();
	user.printCustomer(customers);*/
}
}