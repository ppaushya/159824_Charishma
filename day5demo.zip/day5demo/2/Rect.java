package org.cap.demo;

public class Rect implements Area {

	public float Cal(float x,float y)
	{
		return (x*y);
	}

}
