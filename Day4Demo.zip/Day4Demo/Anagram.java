package org.cap.demo;

import java.util.Arrays;

public class Anagram {
	char Arr1[];
	char Arr2[];
	public void Ag(String str1)
	{
		char temp1;
	Arr1=new char[str1.length()];
	for(int i=0;i<str1.length();i++)
	{
		Arr1[i]=str1.charAt(i);
	}
		for(int j=0;j<str1.length();j++)
		{
			for(int k=j+1;k<str1.length();k++) {
				if(Arr1[j]>Arr1[k])
				{
					temp1=Arr1[j];
Arr1[j]=Arr1[k];
Arr1[k]=temp1;
			}
		}
	}
	}
	public void Ag1(String str2)
	{
		char temp2;
	Arr2=new char[str2.length()];
	for(int i=0;i<str2.length();i++)
	{
		Arr2[i]=str2.charAt(i);
	}
	for(int j=0;j<str2.length();j++)
	{
		for(int k=j+1;k<str2.length();k++) {
			if(Arr2[j]>Arr2[k])
			{
				temp2=Arr2[j];
Arr2[j]=Arr2[k];
Arr2[k]=temp2;
		}
	}
}
	}
		public void Anag()
		{
			if(Arrays.equals(Arr1,Arr2)==true)
			{
				System.out.println("Anagrams");
			}
			else
			{
				System.out.println("Not Anagrams");
			}
		}
	
	public static void main(String[] args) {
	Anagram ag=new Anagram();
	ag.Ag("robed");
	ag.Ag1("brred");
	ag.Anag();

	}

}
