package org.cap.demo;

public class SumOfDigits {
public void sod(int num)
{
	int sum=0,p;
	do
	{
	p=num%10;
	sum+=p;
	num=num/10;
	}while(num>0);
	System.out.print(sum);
}
	public static void main(String[] args) {
		SumOfDigits sd=new SumOfDigits();
		sd.sod(2344);
		// TODO Auto-generated method stub

	}

}
