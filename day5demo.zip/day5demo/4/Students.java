package org.cap.demo;

public interface Students {
void Display_grade();
void Attendance();
}
