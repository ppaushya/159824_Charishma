package cap.org.boot;

import java.util.Scanner;

import org.cap.dao.IRegDb;
import org.cap.dao.RegDbImpl;
import org.cap.model.Registration;
import org.cap.view.UserInteraction;

public class BootClass {

	public static void main(String[] args) {
		UserInteraction ui=new UserInteraction();
		IRegDb regd=new RegDbImpl();
		Scanner sc=new Scanner(System.in);
		System.out.println("1.CustomerRegistration 2.Exit");
		int choice=sc.nextInt();
		switch(choice)
		{
		case 1:
			Registration r=ui.PromptRegDeatils();
			regd.createRegistration(r);
		break;
		case 2:
			
			System.exit(0);
			default:
				System.out.println("Invalid option");
				System.exit(0);
		}
	}

}
