package org.cap.controller;

import java.util.List;

import org.cap.model.Customer;
import org.cap.service.ICustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@CrossOrigin(origins= {"*"})
@RestController
@RequestMapping("/api")
public class CustomerController {
	
	@Autowired
	private ICustomerService customerService;
	
	
	@GetMapping(value="/customers")
	public ResponseEntity<List<Customer>> getAllCustomers(){
		List<Customer> customers= customerService.getAllCustomers();
		
		if(customers.isEmpty())
			return new ResponseEntity
					("Sorry! Customer list not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	@PostMapping(value="/postcustomers")
	public ResponseEntity<List<Customer>>createCustomer(@RequestBody Customer customer
	){
	
	List<Customer > customers= customerService.createCustomer(customer);
	if(customers==null)
	return new ResponseEntity
	("Sorry! Customer not created!", HttpStatus.NOT_IMPLEMENTED);
	return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}


	@PutMapping(value="/putcustomers")
	public ResponseEntity<List<Customer>> createCustomers(@RequestBody Customer customer){
		
		List<Customer> customers= customerService.updateCustomer(customer);
		
		if(customers.isEmpty())
			return new ResponseEntity
					("invalid insertion", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}

	
	
	@GetMapping(value="/deletecustomers/{custId}")
	public ResponseEntity<List<Customer>>deletCustomer(
			@PathVariable("custId")Integer custId){
		List<Customer> customers= customerService.deleteCustomer(custId);
		
		if(customers==null)
			return new ResponseEntity
					("Sorry! Customer Id not available!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<List<Customer>>(customers, HttpStatus.OK);
	}
	
	
	@GetMapping(value="/customers/{custId}")
	public ResponseEntity<Customer> findCustomers(
			@PathVariable("custId")Integer custId){
		Customer customer= customerService.findCustomer(custId);
		
		if(customer==null)
			return new ResponseEntity
					("Sorry! Customer ID does not exists!", HttpStatus.NOT_FOUND);
		
		return new ResponseEntity<Customer>(customer, HttpStatus.OK);
	}

	
	
	
	
	
	
	
	
	
	
	
	
	
}
