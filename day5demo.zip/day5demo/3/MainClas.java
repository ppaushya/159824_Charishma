package org.cap.demo;

public class MainClas {

	public static void main(String[] args) {
	Math ma=new Calc();
	ma.division(24, 2);
ma.modulus(24, 5);
	}

}
