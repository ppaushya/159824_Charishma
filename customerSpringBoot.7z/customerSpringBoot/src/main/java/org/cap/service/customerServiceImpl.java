package org.cap.service;

import java.util.List;

import org.cap.dao.ICustomerDao;
import org.cap.model.Customer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service("customerService")
public class customerServiceImpl implements ICustomerService{
	@Autowired
private ICustomerDao customerDao;
	@Override
	public List<Customer> getAllCustomers() {
		
		return customerDao.findAll();
	}

	@Override
	public List<Customer> createCustomer(Customer customer) {
		
		 customerDao.save(customer);
		 return customerDao.findAll();
	}

	@Override
	public List<Customer> updateCustomer(Customer customer) {
		
		customerDao.save(customer);
		 return customerDao.findAll();
	}

	@Override
	public List<Customer> deleteCustomer(Integer custId) {
		Customer cust=customerDao.findById(custId).get();
		 customerDao.delete(cust);
		
		 return customerDao.findAll();
	}

	@Override
	public Customer findCustomer(Integer custId) {
		Customer cust=customerDao.findById(custId).get();
		return cust;
	}

}
