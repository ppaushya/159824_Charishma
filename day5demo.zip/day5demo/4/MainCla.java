package org.cap.demo;

public class MainCla {

	public static void main(String[] args) {
	Pg_student pg=new Pg_student();
	Ug_students ug=new Ug_students();
	Students st;
	st=pg;
	st.Display_grade();
	st.Attendance();
	st=ug;
	st.Display_grade();
st.Attendance();
	}

}
