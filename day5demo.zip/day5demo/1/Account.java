package Balance;

public class Account {
public void DisplayBal()

{
	System.out.println("Balance Display");
}
}
