package org.capg.util;

public class Utility {
public static int generateNumber()
{
	return (int)(Math.random()*1000/10);
}
public static boolean isValidation(String fname) {
	
		return(fname.matches("[A-Za-z]{3,}"));
}

public static boolean isValidationphno(String phno)
{
	return(phno.matches("^([1-9][0-9]{9})$"));
			
}
public static boolean isValidationemail(String email)
{
	
		return(email.matches("^([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[A-Za-z]{2,6})$"));
			
		}
public static boolean isValidationPin(String pin)
{
	
		return(pin.matches("\\d{6}"));
			
		}
}


