package org.capg.dao;

import java.time.LocalDate;

import java.util.ArrayList;
import java.util.List;

import org.capg.model.Account;
import org.capg.model.Address;
import org.capg.model.Customer;

public class CustomerDaoImpl implements ICustomerDao{
	
	private static List<Customer> customers=dummyDb();
	
	private static List<Customer> dummyDb(){
		List<Customer> customers=new ArrayList<>();
		
		Address address=new Address("23,west Car St", "2nd St", "Chennai", "TN", "234442");
		customers.add(new Customer(123,"Jack","Thomson", LocalDate.of(1991, 01, 23),
				"jack@gmail.com","8890912345",address));
		
		Address address1=new Address("North Avnnue", "2nd Cross St", "Hyderabad", "AP", "657657");
		customers.add(new Customer(1090,"Tom","Jerry", LocalDate.of(1987, 12, 23),
				"tom@gmail.com","9090912345",address1));
		
		return customers;
	}

	@Override
	public List<Customer> getAllCustomers() {
		
		return customers;
	}

	@Override
	public void createCustomer(Customer customer) {
		
		customers.add(customer);
	}

	@Override
	public Customer isFound(int customerId) {
		// TODO Auto-generated method stub
		//Customer c1=new Customer();
		
		for(Customer customer:getAllCustomers()) {
			if(customer.getCustomerId()==customerId)
				return customer;
		}
		
		return null;
	}

	@Override
	public void setAccountDetails(Customer customer, Account account) {
		customer.getAccount().add(account);		
	}

}
