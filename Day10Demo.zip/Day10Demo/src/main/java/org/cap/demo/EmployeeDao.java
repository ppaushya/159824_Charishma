package org.cap.demo;

import java.util.List;

public interface EmployeeDao {
	
	public void createEmployee(Employee employee);
	public void deleteEmployee(int employeeId);
	public void UpdateEmployee(Employee employee);
	public List<Employee>  getAllEmployees();
	public Employee findEmployee(int emp1Id);
//public void UpdateEmployee(int empId);
}
