package org.capg.dao;
import org.capg.model.Customer;
import org.capg.model.Address;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.capg.model.Address;
public class CustomerDaoImp1 implements ICustomerDao{
	private static List<Customer> customers=dummyDb();

	private static List<Customer> dummyDb() {
		List<Customer> customers =new ArrayList<>();
		Address address=new Address("hsr","katuru","Vij","Ap","521165");
		customers.add(new Customer(123,"Jack","Thompson",LocalDate.of(1991, 01, 23),"7847590332","jack@gmail.com",))
	}
	

}
