package org.cap.demo;

import java.util.Scanner;

public class Matrix {
	
	
	int r;
	int c;
	int arr[][];
	public void input()
	{
		Scanner sc=new Scanner(System.in);
		r=sc.nextInt();
		c=sc.nextInt();
		if(r==c)
		{
			arr=new int[r][c];
		for(int i=0;i<r;i++)
		{
			for(int j=0;j<c;j++) {
				arr[i][j]=sc.nextInt();
			}
			
			
		}
		}
		else
		{
			System.out.print("array Cannot b accepted");
	}
		sc.close();
	}
public void upper()
{
	System.out.println("upper");
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			if(i>j)
				System.out.print(" "+"\t");
			else
				System.out.print(arr[i][j]+"\t");
		}
		System.out.println();
	}
}
public void lower()
{
	System.out.println("lower");
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			if(i<j)
				System.out.print(" "+"\t");
			else
				System.out.print(arr[i][j]+"\t");
		}
		System.out.println();
	}
}
public void transpose() {
	System.out.println("transpose");
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++) {
			System.out.print(arr[j][i]+"\t");;
		}
		System.out.println();
		
	}
	
}
public static void main(String[] args) 
{
		Matrix mt=new Matrix();
		mt.input();
		mt.upper();
		mt.lower();
		mt.transpose();
		

}
}
