package org.cap.demo;

public interface Area {
	
final static float pi=3.142f;
void float Cal(float x,float y);


}
