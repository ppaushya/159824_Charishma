package org.cap.demo;

public class ArmstrongNo {
	public void ASno(int num)
	{int sum=0,p;
	int r=num;
	do
	{
		p=r%10;
		sum+=(p*p*p);
		r=r/10;
	}while(r>0);
if(num==sum)
	System.out.println(num+" "+ "is armstrong");

}
	public static void main(String[] args) {
		ArmstrongNo an=new ArmstrongNo();

		// TODO Auto-generated method stub
for(int i=1;i<=1000;i++)	
{
	an.ASno(i);
}
	}

}
