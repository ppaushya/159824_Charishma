package org.cap.service;

import java.util.List;

import org.cap.model.Customer;

public interface ICustomerService {

	List<Customer> getAllCustomers();

	List<Customer> createCustomer(Customer customer);

	List<Customer> updateCustomer(Customer customer);

	List<Customer> deleteCustomer(Integer custId);

	Customer findCustomer(Integer custId);

}
