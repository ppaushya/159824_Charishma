package org.cap.demo;

public class Main {

	public static void main(String[] args) {
	Rect rec=new Rect();
	Area ar;
	ar=rec;
	System.out.println("Rect area is:"+ar.Cal(5,6));
	Circ cir=new Circ();
	ar=cir;
	System.out.println("Circle area is:"+ar.Cal(5,6));

	}

}
