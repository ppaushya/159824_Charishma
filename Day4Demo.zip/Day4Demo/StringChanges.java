package org.cap.demo;

public class StringChanges{
    char Arr[];
    public void LetterChanges(String str)
    {
        Arr=new char[str.length()];
        for(int i=0;i<str.length();i++)
        {
        Arr[i]=str.charAt(i);
        }
        for(int i=0;i<str.length();i++)
        {
            if(Arr[i]!=' ')
            Arr[i]=(char)(Arr[i]+(char)1);
        }
        for(int j=0;j<str.length();j++)
        {
            if((int)Arr[j]==97 ||(int)Arr[j]==101 ||(int)Arr[j]==105 ||(int)Arr[j]==111 ||(int)Arr[j]==117 )
            {
                Arr[j]=(char)(Arr[j]-(char)32);
            }
        }
        for(int k=0;k<str.length();k++)
        {
            System.out.print(Arr[k]);
        }
    }

     public static void main(String []args){
        StringChanges sc=new StringChanges();
        sc.LetterChanges("you are sn sweet");
     }
}