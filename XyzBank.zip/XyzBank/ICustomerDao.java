package org.capg.dao;

public interface ICustomerDao {

}
