package org.cap.demo;

import java.util.Scanner;

public class StringFormat {

	public static void main(String[] args) {

	
Scanner sc=new Scanner(System.in);
String s1=sc.next();
int len=s1.length();
for(int i=0;i<len;i++)
{
	for(int j=0;j<=i;j++)
	{
		System.out.print(s1.charAt(j));
	}
	System.out.println();
}
}
}
