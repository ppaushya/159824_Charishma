package org.cap.demo;

public class StriAlp {
	char Arr[];
	
	char temp;
public void AlphabetSoup(String str)
{
	Arr=new char[str.length()];
	for(int i=0;i<str.length();i++)
	{
		Arr[i]=str.charAt(i);
	}
	for(int i=0;i<str.length();i++) {
		for(int j=i+1;j<str.length();j++)
		{
			if(Arr[i]>=Arr[j])
			{
			temp=Arr[i];
			Arr[i]=Arr[j];
			Arr[j]=temp;
			}
		}
	}
	for(int i=0;i<str.length();i++) 
		
		{
			System.out.print(Arr[i]);
		}
	
	
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
StriAlp sa=new StriAlp();
sa.AlphabetSoup("charishma");
	}

}
